package com.itmo.server.url;

public interface UrlGetter {
    String getUrl();
}
